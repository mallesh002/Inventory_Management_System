import React from 'react';

function UserDashboard() {
  return (
    <div>
      <h1>User Dashboard</h1>
      <p>Welcome to the user dashboard!</p>
    </div>
  );
}

export default UserDashboard;
