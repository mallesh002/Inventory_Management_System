import React from 'react';

function AddNewItem() {
  return (
    <div>
      <h1>Add New Item</h1>
      <p>Use this page to add new items to the inventory.</p>
    </div>
  );
}

export default AddNewItem;
