import React from 'react';

function Settings() {
  return (
    <div>
      <h1>Settings</h1>
      <p>Adjust your settings here.</p>
    </div>
  );
}

export default Settings;
