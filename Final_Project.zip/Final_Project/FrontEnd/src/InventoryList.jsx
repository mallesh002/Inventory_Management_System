import React from 'react';

function InventoryList() {
  return (
    <div>
      <h1>Inventory List</h1>
      <p>Here is the list of inventory items.</p>
    </div>
  );
}

export default InventoryList;
